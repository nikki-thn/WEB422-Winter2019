//only needs this library, require is deprecated, use import
import React from 'react';

class Clock extends React.Component {
    constructor(props) {
      super(props);
      this.state = {date: new Date()}; //Set the state
    }
  
    //To manage the state of a component, similar to Document.ready() or a Constructor
    componentDidMount() {
        this.timerID = setInterval(
            () => this.tick(),
            1000);
    }
    
    //To do sth before the component is remove (destructor)
    componentWillUnmount() {
        clearInterval(this.timerID);
    }
  
    tick() {
        this.setState({
          date: new Date()
        });
      }
    
      render() {
        return (
          <div>
            <h1>Hello, world!</h1>
            <h2>It is {this.state.date.toLocaleTimeString()}.</h2>
          </div>
        );
      }
  }

  //Consider this a JS module
export default Clock;