//only needs this library, require is deprecated, use import
import React, { Component } from 'react';

/*** CREATE COMPONENT USING CLASS */
// class Course extends React.Component {
//   render() {
//     return ( 
//     //create 2 properties: code & desc (user-defined)
//     //Multiple elements must be wrapped in a <div>
//       <div>
//         <p>Code: {this.props.code } </p> 
//         <p>Description: {this.props.desc}</p>
//       </div>  
//     );
//   }
// }

/*** CREATE COMPONENT USING FUNCTION */
function Course(props) {
  return (
    <div>
      <p>Code: {props.code} </p> 
      <p>Description: {props.desc}</p>
    </div>
  );
}

/** DATA INSIDE COMPONENTS */
/*
  1. Properties: must be passed in, should not change (JS object property: value)
  2. States: similar to properties, can be changed, managed by the component
  
  Difference between Property vs State: whether it should be changed 
      while passing back & forth in a component
*/


//Consider this a JS module
export default Course;