import React, { Component} from 'react';
import logo from './logo.svg';
import './App.css';
import { Route, Switch, Redirect, Link } from 'react-router-dom'

class Home extends Component {
  render() {
    return <h1>Home Page</h1>
  }
}

class Projects extends Component {
  render() {
    return <h1>All Projects Page</h1>
  }
}

class Project extends Component {
  render() {
    return <h1>Project {this.props.id} Page</h1>
  }
}

class NotFound extends Component {
  render() {
    return (
      <div>
        <h1 className="page-header">{this.props.title}</h1>
        Page Not Found
      </div>
    );
  }
}


class App extends Component {
  render() {
    return (
      <Switch>
        <Route exact path='/' render={() => (
          <Home />
        )} />
        <Route exact path='/Projects' render={() => (
          <Projects />
        )} />
        <Route path='/Project/:id' render={(props) => (
          <Project id={props.match.params.id} />
        )} />
        <Route path='/testRedirect' render={() => (
          <Redirect push to={"/"} />
        )} />
        <Route path='/NotFound' render={() => (
          <NotFound title="404 Error"/>
        )} />
        <Route render={() => (
          <Link to="/NotFound">My route </Link>
        )} />
      </Switch>
    );
  }
}

export default App;
